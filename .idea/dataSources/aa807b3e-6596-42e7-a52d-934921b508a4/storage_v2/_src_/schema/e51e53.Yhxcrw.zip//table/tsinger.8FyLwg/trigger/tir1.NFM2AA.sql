create definer = root@localhost trigger tir1
  after UPDATE
  on tsinger
  for each row
BEGIN

	#把被修改的tsinger的  sid ,sname , dispaly ,新的描述. 修改时间 
	insert into trecord values(REPLACE(uuid(),'-',''),old.sid,old.sname,old.display,new.display,now());
end;

