create
  definer = root@localhost procedure pro1(IN argID int, IN argDIS varchar(100), OUT count int)
BEGIN
		
	declare flag int default 0;
	declare continue handler for sqlexception set flag =1;
	#
	start transaction;
	update tsinger set sdisplay = argDIS where sid = argID;

	update tsinger set ssalary = ssalary*3 where ssalary<10000;
	update tsinger set ssalary = ssalary*1.1 where ssalary>=10000;
	if flag !=1 then 
		commit;
	else 
		rollback;
	end if;
	set count = (select count(*) from tsinger where ssalary>10000);
end;

