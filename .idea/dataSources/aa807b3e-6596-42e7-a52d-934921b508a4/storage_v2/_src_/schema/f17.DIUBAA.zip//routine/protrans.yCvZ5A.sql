create
  definer = root@localhost procedure protrans(IN newname varchar(20), IN newdisplay varchar(100), IN str varchar(3),
                                              OUT count int)
begin
		#定义一个标志变量 
		declare flag int default 0;
		#定义如果出现了sql异常.就设置flag为1
		declare continue handler for sqlexception set flag = 1;
		#开始事务
		start transaction;
		#1新增记录
		insert into tsinger (sname,sdisplay) values (newname,newdisplay);
		#2删除记录. 
		delete from tsinger where sname like CONCAT('%',str,'%');
		#提交或回滚/.
		if flag!=1 then 
			commit;
		ELSE	
			ROLLBACK;
		end if;
		#查询 记录数.
		set count = (select count(*) from tsinger);
end;

