create
  definer = root@localhost procedure protrans(IN newname varchar(20), IN newdisplay varchar(100), OUT result int)
BEGIN
	declare isDo int default 1;-- 事务成功  
	#声明 事务处理器 当发现异常时 设置isDo = 0
	declare continue handler for sqlexception set isDo = 0;
	#开始事务
	start transaction;
	insert into tsinger (sname,display) values (newname,newdisplay);
	delete from tsinger where LENGTH(sname)=8 and sex = '女';
	if isDo=1 then 
		commit;
	ELSE	
		ROLLBACK;
	end if;
	set result = isDo;
end;

