create definer = root@localhost view nvstu as
select `e51e53`.`stu`.`sid`   AS `sid`,
       `e51e53`.`stu`.`sname` AS `sname`,
       `e51e53`.`stu`.`ssex`  AS `ssex`,
       `e51e53`.`stu`.`sage`  AS `sage`
from `e51e53`.`stu`
where ((`e51e53`.`stu`.`ssex` = '女') and (`e51e53`.`stu`.`sage` >= 20));

