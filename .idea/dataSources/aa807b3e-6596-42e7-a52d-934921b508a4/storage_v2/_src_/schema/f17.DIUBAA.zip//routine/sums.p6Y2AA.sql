create
  definer = root@localhost procedure sums(OUT salas decimal(8, 2))
BEGIN
	declare c DECIMAL(7,2) default 0; # 接收每一次游标里的ssalary 
	declare flag int default 0;
	#声明一个游标 游标是来自查询tsigner表的所有ssalary
	declare cur1 cursor for select ssalary from tsinger;
	#声明一个继续执行的句柄  监控游标循环到最后 找不到数据了  游标(java迭代器)就遍历完成.,
	declare continue handler for not found set flag = 1;
	set salas = 0;
	#开始游标
	open cur1;
	-- -----------
	#取一条游标里的数据 到 一个变量c中
	fetch cur1 into c;
	#当 flag 不是1的时候 说明 游标还没遍历完/
	while flag !=1 DO
		if c is not null then 
			set salas = salas+c;
		end if;
		fetch cur1 into c;#继续 向下一行游标 索要数据
	end while;
	-- -----------
	#关闭游标
	close cur1;
end;

