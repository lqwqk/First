create definer = root@localhost view nv20 as
select `f17`.`tstudent`.`sid`    AS `sid`,
       `f17`.`tstudent`.`sname`  AS `sname`,
       `f17`.`tstudent`.`sage`   AS `sage`,
       `f17`.`tstudent`.`ssex`   AS `ssex`,
       `f17`.`tstudent`.`saddr`  AS `saddr`,
       `f17`.`tstudent`.`sphone` AS `sphone`
from `f17`.`tstudent`
where ((`f17`.`tstudent`.`ssex` = '女') and (`f17`.`tstudent`.`sage` <= 20));

