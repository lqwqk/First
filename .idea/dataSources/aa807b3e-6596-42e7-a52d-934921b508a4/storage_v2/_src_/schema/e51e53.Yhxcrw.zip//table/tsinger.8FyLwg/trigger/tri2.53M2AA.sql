create definer = root@localhost trigger tri2
  before INSERT
  on tsinger
  for each row
begin 
	
	if new.salary is null then 
		set new.salary = 1000.01;
	end if;
	if new.birthday is null then 
		set new.birthday = now();
	end if;
end;

